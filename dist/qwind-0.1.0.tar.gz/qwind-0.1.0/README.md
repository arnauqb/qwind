# qwind
A non-hydrodynamical model for AGN line-drive winds.
